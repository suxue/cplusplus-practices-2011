#include<iostream>
using namespace std;
int main()
{
	short i,j;
	for(i=65;i<=90;i++)
	cout<<(char)i<<endl;
	for(j=90;j>=65;j--)
	cout<<(char)j<<endl;
}

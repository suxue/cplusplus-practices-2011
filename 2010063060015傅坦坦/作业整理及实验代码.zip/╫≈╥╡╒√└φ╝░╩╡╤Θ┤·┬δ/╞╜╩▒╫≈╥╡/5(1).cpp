#include<iostream>
using namespace std;
int main()
{
	const int MaxN=10;
	int n,a[MaxN],i,j;
	for(n=0;n<MaxN;n++)
	{
		cin>>a[n];
		if(a[n]<0)
			break;
	}
	for(i=0;i<n-1;i++)
		for(j=i;j<n;j++)
			if((a[i]%2==a[j]%2)&&a[i]>a[j]||a[i]%2<a[j]%2)
			{
				int t;
				t=a[i];
				a[i]=a[j];
				a[j]=t;
			}                   
	for(i=0;i<n;i++)
	cout<<a[i]<<"\t";
	return 0;
}
#include<iostream>
using namespace std;
int check1(char *a)
{
	int L=strlen(a);
	for(int i=0;i<L/2;i++)
		if(a[i]!=a[L-1-i])
			return 0;
		return 1;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
}
int main()
{
	char zifuchuan[100];
	cin>>zifuchuan;
	if(check1(zifuchuan))
		cout<<"�ǻ���";
	else 
		cout<<"���ǻ���";
}
#include<iostream>
using namespace std;
struct Text
{
	char number[15];
	char name[20];
}Text1[]={{"01088888888","�����"},
		  {"01086123897","���"},
		  {"13151111191","С��Ů"},
		  {"15988886543","����"},	
};
int check1(char * p,char * q){
	int L1,L2;
	L1=strlen(p);
	L2=strlen(q);
	if(L1<L2)
		return 0;
	for(int i=0;i<L2;i++)
		{
		if(q[i]!=p[i])
			{return 0;
		else
			{return 1;
			break;}
		}
}

int main()
{
	int n=4;
	char a[15];
	cout<<"������绰���������";
	cin>>a;
	for(int i=0;i<n;i++){
		if(Text1[i].number,a)
			cout<<Text1[i].number<<Text1[i].name<<endl;
	}
	for(int i=0;i<n;i++){
		if(Text1[i].name,a)
			cout<<Text1[i].number<<Text1[i].name<<endl;
	}
}
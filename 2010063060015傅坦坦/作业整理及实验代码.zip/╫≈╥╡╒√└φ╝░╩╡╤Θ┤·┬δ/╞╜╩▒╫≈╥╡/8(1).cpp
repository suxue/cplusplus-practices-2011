#include<iostream>
using namespace std;
class Point{
	public:
		Point(float a,float b)
		{
			x=a;
			y=b;
		}
	private:
		float x;
		float y;
};
class Rectangle:public Point{
	public:
		Rectangle(float a,float b,float c,float d);
		float Area()
		{
			return width *high;
		}
	private:
		int width;
		int high;
};
Rectangle::Rectangle(float a,float b,float c,float d):Point(a,b)
{
	width=c;
	high=d;
}
class Circle:public Point{
	public:
		Circle(float x,float y,float z);
		float Area()
		{
			return 3.14*radius*radius;
		}
	private:
		float radius;
};
Circle::Circle(float x,float y,float z):Point(x,y){
	radius=z;
}
int main()
{
	Rectangle R(1,2,3,4);
	cout<<"R.Area()="<<R.Area()<<endl;
	Circle C(5,6,7);
	cout<<"C.Area()="<<C.Area()<<endl;
	return 0;
}
#include<iostream>
using namespace std;
class Point{
	private:
		
	public:
		double Distance(const& Point){
			
		}
};
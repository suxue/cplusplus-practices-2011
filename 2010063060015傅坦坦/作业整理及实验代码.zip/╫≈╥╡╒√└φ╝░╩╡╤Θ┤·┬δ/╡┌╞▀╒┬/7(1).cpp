#include<iostream>
#include <math.h>
using namespace std;
class Ctriangle{
	private:
		int C;
		double S;
		int a,b,c;
	public:
		void receive(int x,int y,int z){
			cout<<"Please input three numbers:";
			cin>>x>>y>>z;
			a=x;
			b=y;
			c=z;
		}
		int zhouchang(){
			C=a+b+c;
			return C;
		}
		double mianji(){
			int p;
			p=(a+b+c)/2;
			S=sqrt(p*(p-a)*(p-b)*(p-c));
			return S;
		}
};
int main()
{
	Ctriangle A;
	A.receive(1,1,1);
	cout<<"����ǣ�"<<A.mianji()<<endl;
	cout<<"�ܳ��ǣ�"<<A.zhouchang()<<endl; 
}
#include<iostream>
using namespace std;
class CDate{
	int year,month,day;
	int y1,m1,d1;
	public:
		void setdate(int y,int m,int d)
		{
			year=y;
			month=m;
			day=d;
		}
		void show()
		{
			cout<<"��ǰ����:"<<day<<"-"<<month<<"-"<<year<<endl;
			cout<<"����һ������"<<d1<<"-"<<m1<<"-"<<y1<<endl;
		}
		void NewDay()
		{
			d1=day;m1=month;y1=year;
			d1++;
			switch(d1)
			{
				case 29:if(!(month==2&&(year%400==0||year%4==0&&year%100!=0)))
						{m1=3;d1=1;};break;
				case 30:if(month==2&&(year%400==0||year%4==0&&year%100!=0))
						{m1=3;d1=1;};break;
				case 31:if(month==4||month==6||month==9||month==11)
						{m1=m1+1;d1=1;}break;
				case 32:m1=m1=1;d1=1;if(month=12){y1=y1+1;m1=1;};break;
			}
		}
};
int main()
{
	CDate d;
	int y,m,d1;
	cout<<"������������";
	cin>>y>>m>>d1;
	d.setdate(y,m,d1);
	d.NewDay();
	d.show();
}